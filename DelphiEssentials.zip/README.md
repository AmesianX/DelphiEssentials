Instructions with If and Else
Example If
Example If Else

Instruction with Case
Example Case

Instructions with Loops
Example For
Example While
Example Repeat

Instructions with Strings
Example String
Example Char

Instructions with Methods
Example Procedure
Example Function

Examples of Applications with Delphi
Example Firemonkey
Example VCL
Example IntraWeb
